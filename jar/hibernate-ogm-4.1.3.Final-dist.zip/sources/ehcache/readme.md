Ehcache Hibernate OGM Provider
==============================

About
-----

    This is the Ehcache provider.

Status
------

1. Tests passing


Anticipated Features
--------------------

Now:

- CRUD operations using EhcacheDialect


Later:

- Search using EHCache's own search instead of Hibernate Search

